# Plants > 2024-12-06 11:32am
https://universe.roboflow.com/robotic-car-detecting-plants/plants-ajndx

Provided by a Roboflow user
License: CC BY 4.0

